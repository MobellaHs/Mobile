
Exercicio 3

void main() {
  double c = 32;
  double f = c*1.8 + 32;
  
  print('A temperatura é $f');
  }


