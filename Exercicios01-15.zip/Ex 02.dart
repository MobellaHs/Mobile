
Exercicio 2

void main() {
  var a = 5;
  var b = 8;
  var c = 2;
  var d = 6;
  
  
  var media = ((a+b+c+d)/4);
  
  print('A media é $media');
  
  }


