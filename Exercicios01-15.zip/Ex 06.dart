
Exercicio 6

void main() {
  double base = 5;
  double altura = 2;
  
  if(base > 100){
    
    print('Terreno Grande');
  }else{
    print('Terreno pequeno');
  }
  }