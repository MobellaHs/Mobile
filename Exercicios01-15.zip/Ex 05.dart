
Exercicio 5

void main() {
  produtos(valor){
    double prod1 = 5;
    double prod2 = 10;
    double prod3 = 32;
    double prod4 = 45;
    double prod5 = 22;
    
    double troco = valor - (prod1+prod2+prod3+prod4+prod5);
        
    print('Troco $troco');
    
  }
    produtos(200);
  }

