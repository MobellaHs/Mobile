
Exercicio 1 

void main() {
  double base = 5;
  double altura = 2;
  
  double area = base* altura;
  
  print('A área do retangulo é $area');
  
  }


