
Exercicio 4

void main() {
  dolar(valor){
    double reais = 5.01;
    print(reais*valor);
  }
  
  dolar(15);
  }


